#include <iostream>
#include <fstream>
#include <string>
#include <sstream> // Required for stringstream
#include <vector>
using namespace std;

using namespace std;
void ClearScreen()
{
    system("cls");
}
bool staffLogin()
{
    string username, password;
    ClearScreen();
    cout << "=== STAFF LOGIN ===" << endl;
    cout << "Username: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    ifstream file("Staff Details.txt");
    if (!file.is_open())
    {
        cerr << "Error: Could not open staff records." << endl;
        return false;
    }

    // Skip the header line
    string header;
    getline(file, header);

    string line;
    bool found = false;

    while (getline(file, line))
    {
        stringstream ss(line);
        string staffID, name, role, email, salary, phone, address, fileUsername, filePassword;

        // Read all fields separated by tabs
        getline(ss, staffID, '\t');
        getline(ss, name, '\t');
        getline(ss, role, '\t');
        getline(ss, email, '\t');
        getline(ss, salary, '\t');
        getline(ss, phone, '\t');
        getline(ss, address, '\t');
        getline(ss, fileUsername, '\t');
        getline(ss, filePassword, '\t');

        if (fileUsername == username && filePassword == password && role == "Reception")
        {

            found = true;
            break;
        }
    }

    file.close();

    if (found)
    {
        cout << "\nLogin successful! Welcome !! " << endl;
        return true;
    }
    else
    {
        return false;
    }
}

// Function to display a welcome message
void welcome()
{
    cout << "===========================================\n";
    cout << "== Welcome to Airline Management System! ==\n";
    cout << "===========================================\n\n";
}

// Function to verify admin credentials

void login()
{
}
bool adminLogin()
{
    string username, password;
    string fileUsername, filePassword;

    cout << "=== ADMIN LOGIN ===" << endl;
    cout << "Username: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    ifstream file("admin.txt");
    if (!file.is_open())
    {
        cerr << "Error: Could not open credentials file." << endl;
        return false;
    }

    // Read username and password from file
    getline(file, fileUsername);
    getline(file, filePassword);

    file.close();

    if (username == fileUsername && password == filePassword)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool updateAdminCredentials()
{
    string newUser, newPass;

    // Get new credentials
    cout << "Enter new username: ";
    cin >> newUser;
    cout << "Enter new password: ";
    cin >> newPass;

    // Open original file
    ifstream inFile("admin.txt");
    if (!inFile)
    {
        cerr << "Error opening admin file.\n";
        return false;
    }
    else
    {
        ofstream outFile("admin.txt");
        if (!outFile)
        {
            cerr << "Error opening admin file for writing.\n";
            return false;
        }
        // Write new credentials
        outFile << newUser << "\n"
                << newPass << "\n";
        outFile.close();
        return true;
    }
}

void addStaff()
{
    ofstream file("Staff Details.txt", ios::app); // Open in append mode
    if (!file.is_open())
    {
        cerr << "Error opening staff file!" << endl;
        return;
    }

    string staffID, name, role, email, salary, phone, address, username, password;

    ClearScreen();
    cout << "=== ADD NEW STAFF MEMBER ===" << endl;

    // Get all staff details
    cout << "Staff ID: ";
    cin.ignore();
    getline(cin, staffID);

    cout << "Full Name: ";
    getline(cin, name);

    cout << "Role: ";
    getline(cin, role);

    cout << "Email: ";
    getline(cin, email);

    cout << "Salary: ";
    getline(cin, salary);

    cout << "Phone: ";
    getline(cin, phone);

    cout << "Address: ";
    getline(cin, address);

    cout << "Username: ";
    getline(cin, username);

    cout << "Password: ";
    getline(cin, password);

    // Write all details to file separated by tabs
    file << staffID << "\t"
         << name << "\t"
         << role << "\t"
         << email << "\t"
         << salary << "\t"
         << phone << "\t"
         << address << "\t"
         << username << "\t"
         << password << "\n";

    file.close();
    cout << "\nStaff member added successfully!" << endl;
    cout << "Press Enter to continue...";
    cin.get();
}

void removeStaffByName()
{
    while (true)
    {
        ClearScreen();
        cout << "=== REMOVE STAFF MEMBER ===" << endl
             << endl;

        string searchName;
        cout << "Enter staff name to remove: ";
        cin.ignore();
        getline(cin, searchName);

        ifstream inFile("Staff Details.txt");
        if (!inFile)
        {
            cout << "Error opening staff records!" << endl;
            cout << "Press Enter to continue...";
            cin.get();
            return;
        }

        // Read entire file into memory
        string content;
        string line;
        bool found = false;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            string id, name;
            getline(ss, id, '\t');   // Read ID
            getline(ss, name, '\t'); // Read name

            // Trim whitespace from name
            name.erase(0, name.find_first_not_of(" \t"));
            name.erase(name.find_last_not_of(" \t") + 1);

            if (name == searchName)
            {
                found = true;
                // Replace with dashes
                content += string(line.length(), '-') + '\n';
            }
            else
            {
                content += line + '\n';
            }
        }
        inFile.close();

        if (found)
        {
            ofstream outFile("Staff Details.txt");
            outFile << content;
            cout << endl
                 << "Staff member removed successfully!" << endl;
        }
        else
        {
            cout << endl
                 << "Staff member not found!" << endl;
        }

        cout << endl
             << "1. Remove another staff" << endl;
        cout << "2. Return to menu" << endl;
        cout << "Enter choice: ";

        int choice;
        cin >> choice;
        if (choice == 2)
        {
            break;
        }
    }
}

void viewAllStaff()
{
    ClearScreen();
    cout << "=== STAFF DETAILS (RAW VIEW) ===" << endl
         << endl;

    ifstream file("Staff Details.txt");
    if (!file.is_open())
    {
        cerr << "Error: Could not open staff records." << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    string line;
    while (getline(file, line))
    {
        cout << line << endl; // Display each line exactly as it appears in file
    }

    file.close();
    cout << endl
         << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}

void updateStaffDetails()
{
    ClearScreen();
    cout << "=== UPDATE STAFF DETAILS ===" << endl
         << endl;

    string searchName;
    cout << "Enter staff name to update: ";
    cin.ignore();
    getline(cin, searchName);

    ifstream inFile("Staff Details.txt");
    if (!inFile)
    {
        cout << "Error opening staff records!" << endl;
        cout << "Press Enter to continue...";
        cin.get();
        return;
    }

    string line;
    bool found = false;
    string updatedContent;
    string oldRecord;

    // Search for staff member
    while (getline(inFile, line))
    {
        stringstream ss(line);
        string id, name, role, email, salary, phone, address, username, password;

        // Read all fields
        getline(ss, id, '\t');
        getline(ss, name, '\t');
        getline(ss, role, '\t');
        getline(ss, email, '\t');
        getline(ss, salary, '\t');
        getline(ss, phone, '\t');
        getline(ss, address, '\t');
        getline(ss, username, '\t');
        getline(ss, password, '\t');

        if (name == searchName)
        {
            found = true;
            oldRecord = line;

            // Display current details
            ClearScreen();
            cout << "=== CURRENT DETAILS ===" << endl;
            cout << "ID: " << id << endl;
            cout << "Name: " << name << endl;
            cout << "Role: " << role << endl;
            cout << "Email: " << email << endl;
            cout << "Salary: " << salary << endl;
            cout << "Phone: " << phone << endl;
            cout << "Address: " << address << endl;
            cout << "Username: " << username << endl;
            cout << "Password: " << password << endl
                 << endl;

            // Get updated details
            cout << "=== ENTER NEW DETAILS ===" << endl;
            cout << "ID (" << id << "): ";
            getline(cin, id);
            cout << "Name (" << name << "): ";
            getline(cin, name);
            cout << "Role (" << role << "): ";
            getline(cin, role);
            cout << "Email (" << email << "): ";
            getline(cin, email);
            cout << "Salary (" << salary << "): ";
            getline(cin, salary);
            cout << "Phone (" << phone << "): ";
            getline(cin, phone);
            cout << "Address (" << address << "): ";
            getline(cin, address);
            cout << "Username (" << username << "): ";
            getline(cin, username);
            cout << "Password (" << password << "): ";
            getline(cin, password);

            // Create updated record
            stringstream updatedRecord;
            updatedRecord << id << "\t" << name << "\t" << role << "\t"
                          << email << "\t" << salary << "\t" << phone << "\t"
                          << address << "\t" << username << "\t" << password;

            updatedContent += updatedRecord.str() + "\n";
        }
        else
        {
            updatedContent += line + "\n";
        }
    }
    inFile.close();

    if (found)
    {
        // Write updated content back to file
        ofstream outFile("Staff Details.txt");
        outFile << updatedContent;
        cout << endl
             << "Staff details updated successfully!" << endl;
    }
    else
    {
        cout << endl
             << "Staff member not found!" << endl;
    }

    cout << "Press Enter to continue...";
    cin.get();
}

// Function to validate date format (YYYY-MM-DD)
bool isValidDate(const string &date)
{
    if (date.length() != 10)
        return false;
    if (date[4] != '-' || date[7] != '-')
        return false;

    try
    {
        int year = stoi(date.substr(0, 4));
        int month = stoi(date.substr(5, 2));
        int day = stoi(date.substr(8, 2));

        if (year < 2023 || year > 2030)
            return false;
        if (month < 1 || month > 12)
            return false;
        if (day < 1 || day > 31)
            return false;

        return true;
    }
    catch (...)
    {
        return false;
    }
}

// Function to add a new flight
void addFlight()
{
    ofstream file("flights.txt", ios::app);
    if (!file.is_open())
    {
        cout << "Error opening flights database!" << endl;
        return;
    }

    string flightID, airline, from, to, depDate, depTime, arrDate, arrTime, duration;
    int totalSeats, availableSeats;
    string status = "Scheduled";

    ClearScreen();
    cout << "=== ADD NEW FLIGHT ===" << endl
         << endl;

    // Get flight details
    cout << "Flight ID (e.g., FL123): ";
    cin >> flightID;

    cout << "Airline Name: ";
    cin.ignore();
    getline(cin, airline);

    cout << "From (Origin Airport Code): ";
    getline(cin, from);

    cout << "To (Destination Airport Code): ";
    getline(cin, to);

    do
    {
        cout << "Departure Date (YYYY-MM-DD): ";
        cin >> depDate;
    } while (!isValidDate(depDate));

    cout << "Departure Time (e.g., 10:30 AM): ";
    cin.ignore();
    getline(cin, depTime);

    do
    {
        cout << "Arrival Date (YYYY-MM-DD): ";
        cin >> arrDate;
    } while (!isValidDate(arrDate));

    cout << "Arrival Time (e.g., 1:15 PM): ";
    cin.ignore();
    getline(cin, arrTime);

    cout << "Duration (e.g., 2h 45m): ";
    getline(cin, duration);

    cout << "Total Seats: ";
    cin >> totalSeats;
    availableSeats = totalSeats; // Initially all seats are available

    // Write to file with tab separation
    file << flightID << "\t" << airline << "\t" << from << "\t" << to << "\t"
         << depDate << "\t" << depTime << "\t" << arrDate << "\t" << arrTime << "\t"
         << duration << "\t" << totalSeats << "\t" << availableSeats << "\t" << status << "\n";

    file.close();
    cout << "\nFlight added successfully!" << endl;
    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}

// Function to update seat availability
void updateFlightSeats(const string &flightID, int change)
{
    ifstream inFile("flights.txt");
    ofstream tempFile("temp_flights.txt");

    if (!inFile || !tempFile)
    {
        cout << "Error accessing flight records!" << endl;
        return;
    }

    string line;
    bool found = false;

    // Copy header
    getline(inFile, line);
    tempFile << line << "\n";

    while (getline(inFile, line))
    {
        stringstream ss(line);
        string currentID;
        getline(ss, currentID, '\t');

        if (currentID == flightID)
        {
            found = true;
            // Extract all fields
            string airline, from, to, depDate, depTime, arrDate, arrTime, duration, status;
            int totalSeats, availableSeats;

            getline(ss, airline, '\t');
            getline(ss, from, '\t');
            getline(ss, to, '\t');
            getline(ss, depDate, '\t');
            getline(ss, depTime, '\t');
            getline(ss, arrDate, '\t');
            getline(ss, arrTime, '\t');
            getline(ss, duration, '\t');
            ss >> totalSeats;
            ss.ignore();
            ss >> availableSeats;
            ss.ignore();
            getline(ss, status, '\t');

            // Update available seats
            availableSeats += change;
            if (availableSeats < 0)
                availableSeats = 0;
            if (availableSeats > totalSeats)
                availableSeats = totalSeats;

            // Update status if needed
            if (availableSeats == 0)
                status = "Booked Out";
            else if (status == "Booked Out")
                status = "Scheduled";

            // Write updated record
            tempFile << flightID << "\t" << airline << "\t" << from << "\t" << to << "\t"
                     << depDate << "\t" << depTime << "\t" << arrDate << "\t" << arrTime << "\t"
                     << duration << "\t" << totalSeats << "\t" << availableSeats << "\t" << status << "\n";
        }
        else
        {
            tempFile << line << "\n";
        }
    }

    inFile.close();
    tempFile.close();

    if (found)
    {
        remove("flights.txt");
        rename("temp_flights.txt", "flights.txt");
    }
    else
    {
        remove("temp_flights.txt");
        cout << "Flight " << flightID << " not found!" << endl;
    }
}

void searchFlightByID()
{
    ClearScreen();
    cout << "=== SEARCH FLIGHT ===" << endl
         << endl;

    string searchID;
    cout << "Enter Flight ID to search: ";
    cin >> searchID;

    ifstream file("flights.txt");
    if (!file.is_open())
    {
        cout << "Error opening flight records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Skip header
    string header;
    getline(file, header);

    string line;
    bool found = false;

    while (getline(file, line))
    {
        stringstream ss(line);
        string flightID;
        getline(ss, flightID, '\t');

        if (flightID == searchID)
        {
            found = true;
            // Extract all details
            string airline, from, to, depDate, depTime, arrDate, arrTime, duration, status;
            int totalSeats, availableSeats;

            getline(ss, airline, '\t');
            getline(ss, from, '\t');
            getline(ss, to, '\t');
            getline(ss, depDate, '\t');
            getline(ss, depTime, '\t');
            getline(ss, arrDate, '\t');
            getline(ss, arrTime, '\t');
            getline(ss, duration, '\t');
            ss >> totalSeats;
            ss.ignore();
            ss >> availableSeats;
            ss.ignore();
            getline(ss, status, '\t');

            // Display flight details
            ClearScreen();
            cout << "=== FLIGHT DETAILS ===" << endl
                 << endl;
            cout << "Flight ID :" << flightID << endl;
            cout << "Airline :" << airline << endl;
            cout << "From :" << from << endl;
            cout << "To :" << to << endl;
            cout << "Departure :" << depDate << " at " << depTime << endl;
            cout << "Arrival :" << arrDate << " at " << arrTime << endl;
            cout << "Duration :" << duration << endl;
            cout << "Total Seats :" << totalSeats << endl;
            cout << "Available :" << availableSeats << endl;
            cout << "Status :" << status << endl;

            break;
        }
    }

    if (!found)
    {
        cout << endl
             << "Flight " << searchID << " not found!" << endl;
    }

    cout << endl
         << "Press Enter to continue...";
    cin.ignore();
    cin.get();
    file.close();
}

void removeFlight()
{
    ClearScreen();
    cout << "=== REMOVE FLIGHT ===" << endl
         << endl;

    string flightID;
    cout << "Enter Flight ID to remove: ";
    cin >> flightID;

    ifstream inFile("flights.txt");
    ofstream tempFile("temp_flights.txt");

    if (!inFile || !tempFile)
    {
        cout << "Error accessing flight records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    string line;
    bool found = false;
    int lineLength = 0;

    // First pass to find the flight and get line length
    while (getline(inFile, line))
    {
        stringstream ss(line);
        string currentID;
        getline(ss, currentID, '\t');

        if (currentID == flightID)
        {
            lineLength = line.length();
            found = true;
            break;
        }
    }

    // Reset file pointer
    inFile.clear();
    inFile.seekg(0);

    // Second pass to process file
    while (getline(inFile, line))
    {
        stringstream ss(line);
        string currentID;
        getline(ss, currentID, '\t');

        if (currentID == flightID)
        {
            // Replace each field with *** while maintaining tab separation
            stringstream newLine;
            string field;

            // First field (Flight ID)
            getline(ss, field, '\t');
            newLine << "***";

            // Remaining fields
            while (getline(ss, field, '\t'))
            {
                newLine << "\t***";
            }

            tempFile << newLine.str() << endl;
        }
        else
        {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (found)
    {
        remove("flights.txt");
        rename("temp_flights.txt", "flights.txt");
        cout << endl
             << "Flight " << flightID << " has been removed (details replaced with ***)." << endl;
    }
    else
    {
        remove("temp_flights.txt");
        cout << endl
             << "Flight " << flightID << " not found!" << endl;
    }

    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}

void viewAllFlights()
{
    ClearScreen();
    cout << "=== ALL FLIGHTS ===" << endl
         << endl;

    ifstream file("flights.txt");
    if (!file.is_open())
    {
        cout << "Error opening flight records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Display header
    string header;
    getline(file, header);
    cout << header << endl;
    cout << string(100, '-') << endl;

    // Count total flights (excluding header)
    int totalFlights = 0;
    string countLine;
    while (getline(file, countLine))
    {
        totalFlights++;
    }
    file.clear();
    file.seekg(0);
    getline(file, header); // Skip header again

    // Display flights using for loop
    for (int i = 0; i < totalFlights; i++)
    {
        string line;
        if (getline(file, line))
        {
            // Format and display each field
            stringstream ss(line);
            string flightID, airline, from, to, depDate, depTime, arrDate, arrTime, duration;
            int totalSeats, availableSeats;
            string status;

            getline(ss, flightID, '\t');
            getline(ss, airline, '\t');
            getline(ss, from, '\t');
            getline(ss, to, '\t');
            getline(ss, depDate, '\t');
            getline(ss, depTime, '\t');
            getline(ss, arrDate, '\t');
            getline(ss, arrTime, '\t');
            getline(ss, duration, '\t');
            ss >> totalSeats;
            ss.ignore();
            ss >> availableSeats;
            ss.ignore();
            getline(ss, status, '\t');

            cout << flightID << "\t"
                 << airline << "\t"
                 << from << "\t"
                 << to << "\t"
                 << depDate << "\t"
                 << depTime << "\t"
                 << arrDate << "\t"
                 << arrTime << "\t"
                 << duration << "\t"
                 << totalSeats << "\t"
                 << availableSeats << "\t"
                 << status << endl;
        }
    }

    file.close();
    cout << endl
         << "Total flights: " << totalFlights << endl;
    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}

// Helper function to update passenger records when flight details change
void updatePassengerFlightDetails(const string &flightID, const string &airline,
                                  const string &from, const string &to,
                                  const string &depDate, const string &arrDate)
{
    ifstream inFile("passengers.txt");
    ofstream tempFile("temp_passengers.txt");

    if (!inFile || !tempFile)
        return;

    string line;
    // Copy header
    getline(inFile, line);
    tempFile << line << endl;

    while (getline(inFile, line))
    {
        stringstream ss(line);
        string currentFlight;
        // Skip to flight number field (9th field)
        for (int i = 0; i < 8; i++)
            getline(ss, currentFlight, '\t');
        getline(ss, currentFlight, '\t');

        if (currentFlight == flightID)
        {
            // Rebuild the line with updated flight info
            stringstream newLine;
            string field;
            ss.clear();
            ss.seekg(0);

            // Copy first 6 fields unchanged (ID to Address)
            for (int i = 0; i < 6; i++)
            {
                getline(ss, field, '\t');
                newLine << field << "\t";
            }

            // Update departure/destination
            newLine << from << "\t" << to << "\t";

            // Skip original from/to
            getline(ss, field, '\t');
            getline(ss, field, '\t');

            // Keep flight number and seat
            getline(ss, field, '\t');
            newLine << field << "\t";
            getline(ss, field, '\t');
            newLine << field << "\t";

            // Status
            getline(ss, field, '\t');
            newLine << field;

            tempFile << newLine.str() << endl;
        }
        else
        {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();
    remove("passengers.txt");
    rename("temp_passengers.txt", "passengers.txt");
}

void updateFlight()
{
    ClearScreen();
    cout << "=== UPDATE FLIGHT ===" << endl
         << endl;

    string searchID;
    cout << "Enter Flight ID to update: ";
    cin >> searchID;

    ifstream inFile("flights.txt");
    if (!inFile)
    {
        cout << "Error opening flight records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    ofstream tempFile("temp_flights.txt");
    if (!tempFile)
    {
        cout << "Error creating temporary file!" << endl;
        inFile.close();
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    string line;
    bool found = false;

    // Copy header
    getline(inFile, line);
    tempFile << line << endl;

    while (getline(inFile, line))
    {
        stringstream ss(line);
        string flightID;
        getline(ss, flightID, '\t');

        if (flightID == searchID)
        {
            found = true;

            // Extract current details
            string airline, from, to, depDate, depTime, arrDate, arrTime, duration, status;
            int totalSeats, availableSeats;

            getline(ss, airline, '\t');
            getline(ss, from, '\t');
            getline(ss, to, '\t');
            getline(ss, depDate, '\t');
            getline(ss, depTime, '\t');
            getline(ss, arrDate, '\t');
            getline(ss, arrTime, '\t');
            getline(ss, duration, '\t');
            ss >> totalSeats;
            ss.ignore();
            ss >> availableSeats;
            ss.ignore();
            getline(ss, status, '\t');

            // Display current details
            ClearScreen();
            cout << "=== CURRENT FLIGHT DETAILS ===" << endl
                 << endl;
            cout << "1. Flight ID:" << flightID << endl;
            cout << "2. Airline:" << airline << endl;
            cout << "3. From:" << from << endl;
            cout << "4. To:" << to << endl;
            cout << "5. Departure Date:" << depDate << endl;
            cout << "6. Departure Time:" << depTime << endl;
            cout << "7. Arrival Date:" << arrDate << endl;
            cout << "8. Arrival Time:" << arrTime << endl;
            cout << "9. Duration:" << duration << endl;
            cout << "10. Total Seats:" << totalSeats << endl;
            cout << "11. Available Seats:" << availableSeats << endl;
            cout << "12. Status:" << status << endl
                 << endl;

            // Store original values for seat validation
            int originalTotal = totalSeats;
            int originalAvailable = availableSeats;
            string originalStatus = status;

            // Get updated information
            cout << "=== ENTER NEW VALUES (press Enter to keep current) ===" << endl
                 << endl;
            string newValue;

            cout << "New Airline (" << airline << "): ";
            cin.ignore();
            getline(cin, newValue);
            if (!newValue.empty())
                airline = newValue;

            cout << "New From (" << from << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                from = newValue;

            cout << "New To (" << to << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                to = newValue;

            cout << "New Departure Date (" << depDate << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                depDate = newValue;

            cout << "New Departure Time (" << depTime << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                depTime = newValue;

            cout << "New Arrival Date (" << arrDate << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                arrDate = newValue;

            cout << "New Arrival Time (" << arrTime << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                arrTime = newValue;

            cout << "New Duration (" << duration << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                duration = newValue;

            // Seat capacity validation
            bool validSeats = false;
            while (!validSeats)
            {
                cout << "New Total Seats (" << totalSeats << "): ";
                getline(cin, newValue);
                if (!newValue.empty())
                {
                    try
                    {
                        int newTotal = stoi(newValue);
                        if (newTotal >= originalTotal - (originalTotal - originalAvailable))
                        {
                            totalSeats = newTotal;
                            validSeats = true;
                        }
                        else
                        {
                            cout << "Error: Total seats cannot be less than booked seats ("
                                 << (originalTotal - originalAvailable) << ")" << endl;
                        }
                    }
                    catch (...)
                    {
                        cout << "Invalid number entered!" << endl;
                    }
                }
                else
                {
                    validSeats = true;
                }
            }

            // Available seats validation
            validSeats = false;
            while (!validSeats)
            {
                cout << "New Available Seats (" << availableSeats << "): ";
                getline(cin, newValue);
                if (!newValue.empty())
                {
                    try
                    {
                        int newAvailable = stoi(newValue);
                        if (newAvailable >= 0 && newAvailable <= totalSeats)
                        {
                            availableSeats = newAvailable;
                            validSeats = true;
                        }
                        else
                        {
                            cout << "Error: Available seats must be between 0 and " << totalSeats << endl;
                        }
                    }
                    catch (...)
                    {
                        cout << "Invalid number entered!" << endl;
                    }
                }
                else
                {
                    validSeats = true;
                }
            }

            // Auto-update status based on seat availability
            if (availableSeats == 0)
            {
                status = "Booked Out";
            }
            else if (status == "Booked Out" && availableSeats > 0)
            {
                status = "Scheduled";
            }

            cout << "New Status (" << status << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                status = newValue;

            // Write updated record
            tempFile << flightID << "\t" << airline << "\t" << from << "\t" << to << "\t"
                     << depDate << "\t" << depTime << "\t" << arrDate << "\t" << arrTime << "\t"
                     << duration << "\t" << totalSeats << "\t" << availableSeats << "\t" << status << endl;

            // Update passenger records if flight details changed
            if (from != airline || to != to || depDate != depDate || arrDate != arrDate)
            {
                updatePassengerFlightDetails(searchID, airline, from, to, depDate, arrDate);
            }
        }
        else
        {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (found)
    {
        remove("flights.txt");
        rename("temp_flights.txt", "flights.txt");
        cout << endl
             << "Flight " << searchID << " updated successfully!" << endl;
    }
    else
    {
        remove("temp_flights.txt");
        cout << endl
             << "Flight " << searchID << " not found!" << endl;
    }

    cout << "Press Enter to continue...";
    cin.get();
}

bool isSeatAvailable(const string &flightNo, const string &seatNo,
                     const string &passengerDeparture, const string &passengerDestination)
{
    // 1. Check flight exists and get route/availability
    ifstream flightsFile("flights.txt");
    if (!flightsFile.is_open())
    {
        cerr << "Error: Flights database not found!" << endl;
        return false;
    }

    string line;
    bool flightFound = false;
    string flightDeparture, flightDestination;
    int availableSeats = 0;

    // Skip header
    getline(flightsFile, line);

    while (getline(flightsFile, line))
    {
        stringstream ss(line);
        string currentFlight;
        getline(ss, currentFlight, '\t'); // FlightID

        if (currentFlight == flightNo)
        {
            flightFound = true;
            getline(ss, currentFlight, '\t');     // Airline
            getline(ss, flightDeparture, '\t');   // From
            getline(ss, flightDestination, '\t'); // To

            // Skip to AvailableSeats (10th field)
            for (int i = 0; i < 6; i++)
                getline(ss, currentFlight, '\t');
            ss >> availableSeats;
            break;
        }
    }
    flightsFile.close();

    if (!flightFound)
    {
        cout << "Error: Flight " << flightNo << " not found!" << endl;
        return false;
    }

    // 2. Validate route match
    if (flightDeparture != passengerDeparture || flightDestination != passengerDestination)
    {
        cout << "Error: Flight " << flightNo << " goes from " << flightDeparture
             << " to " << flightDestination << " (not your selected route)" << endl;
        return false;
    }

    // 3. Check seat availability
    if (availableSeats <= 0)
    {
        cout << "Error: Flight " << flightNo << " is fully booked!" << endl;
        return false;
    }

    // 4. Check if seat is already taken
    ifstream passengersFile("passengers.txt");
    if (passengersFile.is_open())
    {
        // Skip header
        getline(passengersFile, line);

        while (getline(passengersFile, line))
        {
            stringstream ss(line);
            string currentFlight, currentSeat;

            // Extract FlightNo (9th field) and SeatNo (10th field)
            for (int i = 0; i < 8; i++)
                getline(ss, currentFlight, '\t');
            getline(ss, currentFlight, '\t');
            getline(ss, currentSeat, '\t');

            if (currentFlight == flightNo && currentSeat == seatNo)
            {
                passengersFile.close();
                cout << "Error: Seat " << seatNo << " already booked!" << endl;
                return false;
            }
        }
        passengersFile.close();
    }

    return true;
}

void addPassenger()
{
    ClearScreen();
    cout << "=== ADD NEW PASSENGER ===" << endl;

    // Check available flights first
    viewAllFlights(); // Show flights with available seats

    ofstream file("passengers.txt", ios::app);
    if (!file.is_open())
    {
        cout << "Error opening passenger records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    string id, name, email, phone, address, departure, destination, flightNo, seatNo;
    int age;

    // ----- Critical Section: Flight Seat Validation -----
    bool seatAssigned = false;
    while (!seatAssigned)
    {
        cout << "Flight Number: ";
        getline(cin, flightNo);

        cout << "Seat Number: ";
        getline(cin, seatNo);

        cout << "Departure City/Airport: ";
        getline(cin, departure);

        cout << "Destination City/Airport: ";
        getline(cin, destination);

        // Check if seat is available
        if (isSeatAvailable(flightNo, seatNo, departure, destination))
        {
            seatAssigned = true;
        }
        else
        {
            cout << "Seat " << seatNo << " is already booked or invalid. Try again." << endl;
        }
    }

    string status = "Booked";

    // Get passenger details
    cout << "Passenger ID (e.g., P1001): ";
    cin >> id;

    cout << "Full Name: ";
    cin.ignore();
    getline(cin, name);

    cout << "Age: ";
    cin >> age;

    cout << "Email: ";
    cin.ignore();
    getline(cin, email);

    cout << "Phone: ";
    getline(cin, phone);

    cout << "Address: ";
    getline(cin, address);

    // Write to file
    file << id << "\t" << name << "\t" << age << "\t" << email << "\t"
         << phone << "\t" << address << "\t" << departure << "\t"
         << destination << "\t" << flightNo << "\t" << seatNo << "\t" << status << "\n";

    // Decrease available seats in flight
    updateFlightSeats(flightNo, -1); // Ensure this function exists

    cout << "\nPassenger added successfully!" << endl;
    cout << "Press Enter to continue...";
    cin.get();
}

void removePassengerByName()
{
    ClearScreen();
    cout << "=== REMOVE PASSENGER ===" << endl
         << endl;

    string searchName;
    cout << "Enter passenger name to remove: ";
    cin.ignore();
    getline(cin, searchName);

    ifstream inFile("passengers.txt");
    ofstream tempFile("temp_passengers.txt");

    if (!inFile || !tempFile)
    {
        cout << "Error accessing passenger records!" << endl;
        cout << "Press Enter to continue...";
        cin.get();
        return;
    }

    string line;
    bool found = false;

    // Copy header
    getline(inFile, line);
    tempFile << line << endl;

    while (getline(inFile, line))
    {
        stringstream ss(line);
        string currentName;
        // Extract ID (first field)
        string id;
        getline(ss, id, '\t');
        // Extract Name (second field)
        getline(ss, currentName, '\t');

        if (currentName == searchName)
        {
            found = true;
            // Replace each field with $$$$
            stringstream newLine;
            int fieldCount = 0;
            string field;

            // First field (ID)
            newLine << "$$$$";
            fieldCount++;

            // Remaining fields
            while (getline(ss, field, '\t'))
            {
                newLine << "\t$$$$";
                fieldCount++;
            }

            // Ensure we have all 10 fields (including status)
            while (fieldCount < 10)
            {
                newLine << "\t$$$$";
                fieldCount++;
            }

            tempFile << newLine.str() << endl;

            // Extract flight number to update available seats
            string flightNo;
            ss.clear();
            ss.seekg(0);
            // Skip first 8 fields to get FlightNo
            for (int i = 0; i < 8; i++)
                getline(ss, field, '\t');
            getline(ss, flightNo, '\t');

            // Increase available seats
            updateFlightSeats(flightNo, 1);
        }
        else
        {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (found)
    {
        remove("passengers.txt");
        rename("temp_passengers.txt", "passengers.txt");
        cout << endl
             << "Passenger '" << searchName << "' has been removed." << endl;
    }
    else
    {
        remove("temp_passengers.txt");
        cout << endl
             << "Passenger '" << searchName << "' not found!" << endl;
    }

    cout << "1. Remove another passenger" << endl;
    cout << "2. Return to menu" << endl;
    cout << "Enter choice: ";

    int choice;
    cin >> choice;
    if (choice == 1)
    {
        removePassengerByName();
    }
    // Else returns to menu
}

void viewAllPassengers()
{
    ClearScreen();
    cout << "=== ALL PASSENGERS ===" << endl
         << endl;

    ifstream file("passengers.txt");
    if (!file.is_open())
    {
        cout << "Error opening passenger records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Display header
    cout
        << "ID\t"
        << "Name\t"
        << "Age\t"
        << "Email\t"
        << "Phone\t"
        << "Flight\t"
        << "Seat\t"
        << "Status\t" << endl;

    cout << string(100, '-') << endl;

    // Skip file header if exists
    string header;
    getline(file, header);

    string line;
    int passengerCount = 0;
    bool hasRecords = false;

    while (getline(file, line))
    {
        // Skip lines with all $$$$ (removed passengers)
        if (line.find("$$$$") != string::npos)
        {
            continue;
        }

        hasRecords = true;
        passengerCount++;

        stringstream ss(line);
        string id, name, age, email, phone, address, departure, destination, flightNo, seatNo, status;

        // Read all fields
        getline(ss, id, '\t');
        getline(ss, name, '\t');
        getline(ss, age, '\t');
        getline(ss, email, '\t');
        getline(ss, phone, '\t');
        getline(ss, address, '\t');
        getline(ss, departure, '\t');
        getline(ss, destination, '\t');
        getline(ss, flightNo, '\t');
        getline(ss, seatNo, '\t');
        getline(ss, status, '\t');

        // Display formatted passenger info
        cout
            << id << "\t"
            << name << "\t"
            << age << "\t"
            << (email.length() > 24 ? email.substr(0, 24) + "..." : email) << "\t"
            << phone << "\t"
            << flightNo << "\t"
            << seatNo << "\t"
            << status << "\t" << endl;
    }

    file.close();

    if (!hasRecords)
    {
        cout << "No passenger records found!" << endl;
    }
    else
    {
        cout << endl
             << "Total passengers: " << passengerCount << endl;
    }

    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}

void searchPassengerByName()
{
    ClearScreen();
    cout << "=== SEARCH PASSENGER BY NAME ===" << endl
         << endl;

    string searchName;
    cout << "Enter passenger name to search: ";
    cin.ignore();
    getline(cin, searchName);

    ifstream file("passengers.txt");
    if (!file.is_open())
    {
        cout << "Error opening passenger records!" << endl;
        cout << "Press Enter to continue...";
        cin.get();
        return;
    }

    // Skip header
    string header;
    getline(file, header);

    string line;
    bool found = false;
    int resultCount = 0;

    while (getline(file, line))
    {
        // Skip removed passengers (lines with $$$$)
        if (line.find("$$$$") != string::npos)
        {
            continue;
        }

        stringstream ss(line);
        string id, name;

        // Get ID and Name (first two fields)
        getline(ss, id, '\t');
        getline(ss, name, '\t');

        if (name == searchName)
        {
            found = true;
            resultCount++;

            // Extract remaining fields
            string age, email, phone, address, departure, destination, flightNo, seatNo, status;
            getline(ss, age, '\t');
            getline(ss, email, '\t');
            getline(ss, phone, '\t');
            getline(ss, address, '\t');
            getline(ss, departure, '\t');
            getline(ss, destination, '\t');
            getline(ss, flightNo, '\t');
            getline(ss, seatNo, '\t');
            getline(ss, status, '\t');

            // Display passenger details
            if (resultCount == 1)
            {
                cout << "=== SEARCH RESULTS ===" << endl
                     << endl;
            }
            cout << "Result #" << resultCount << endl;
            cout << string(40, '-') << endl;
            cout << "Passenger ID:" << id << endl;
            cout << "Name:" << name << endl;
            cout << "Age:" << age << endl;
            cout << "Email:" << email << endl;
            cout << "Phone:" << phone << endl;
            cout << "Address:" << address << endl;
            cout << "Departure:" << departure << endl;
            cout << "Destination:" << destination << endl;
            cout << "Flight No:" << flightNo << endl;
            cout << "Seat No:" << seatNo << endl;
            cout << "Status:" << status << endl
                 << endl;
        }
    }

    file.close();

    if (!found)
    {
        cout << "No passengers found with name: '" << searchName << "'" << endl;
    }
    else
    {
        cout << "Total matches found: " << resultCount << endl;
    }

    cout << "Press Enter to continue...";
    cin.get();
}

void updatePassengerDetails()
{
    ClearScreen();
    cout << "=== UPDATE PASSENGER DETAILS ===" << endl
         << endl;

    string searchID;
    cout << "Enter Passenger ID to update: ";
    cin >> searchID;

    ifstream inFile("passengers.txt");
    ofstream tempFile("temp_passengers.txt");

    if (!inFile || !tempFile)
    {
        cout << "Error accessing passenger records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    string line;
    bool found = false;

    // Copy header
    getline(inFile, line);
    tempFile << line << endl;

    while (getline(inFile, line))
    {
        stringstream ss(line);
        string currentID;
        getline(ss, currentID, '\t');

        if (currentID == searchID)
        {
            found = true;

            // Extract current details
            string name, age, email, phone, address, departure, destination, flightNo, seatNo, status;
            getline(ss, name, '\t');
            getline(ss, age, '\t');
            getline(ss, email, '\t');
            getline(ss, phone, '\t');
            getline(ss, address, '\t');
            getline(ss, departure, '\t');
            getline(ss, destination, '\t');
            getline(ss, flightNo, '\t');
            getline(ss, seatNo, '\t');
            getline(ss, status, '\t');

            // Display current details
            ClearScreen();
            cout << "=== CURRENT PASSENGER DETAILS ===" << endl
                 << endl;
            cout << "Passenger ID:" << currentID << endl;
            cout << "Name:" << name << endl;
            cout << "Age:" << age << endl;
            cout << "Email:" << email << endl;
            cout << "Phone:" << phone << endl;
            cout << "Address:" << address << endl;
            cout << "Departure:" << departure << endl;
            cout << "Destination:" << destination << endl;
            cout << "Flight No:" << flightNo << endl;
            cout << "Seat No:" << seatNo << endl;
            cout << "Status:" << status << endl
                 << endl;

            // Get updated information
            cout << "=== ENTER NEW VALUES (press Enter to keep current) ===" << endl
                 << endl;
            string newValue;

            cout << "New Name (" << name << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                name = newValue;

            cout << "New Age (" << age << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                age = newValue;

            cout << "New Email (" << email << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                email = newValue;

            cout << "New Phone (" << phone << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                phone = newValue;

            cout << "New Address (" << address << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                address = newValue;

            cout << "New Departure (" << departure << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                departure = newValue;

            cout << "New Destination (" << destination << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                destination = newValue;

            string oldFlightNo = flightNo;
            string oldSeatNo = seatNo;

            cout << "New Flight No (" << flightNo << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                flightNo = newValue;

            cout << "New Seat No (" << seatNo << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                seatNo = newValue;

            cout << "New Status (" << status << "): ";
            getline(cin, newValue);
            if (!newValue.empty())
                status = newValue;

            // Handle seat changes if flight or seat was modified
            if (oldFlightNo != flightNo || oldSeatNo != seatNo)
            {
                updateFlightSeats(oldFlightNo, 1); // Free up old seat
                updateFlightSeats(flightNo, -1);   // Reserve new seat
            }

            // Write updated record
            tempFile << currentID << "\t" << name << "\t" << age << "\t"
                     << email << "\t" << phone << "\t" << address << "\t"
                     << departure << "\t" << destination << "\t"
                     << flightNo << "\t" << seatNo << "\t" << status << endl;
        }
        else
        {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (found)
    {
        remove("passengers.txt");
        rename("temp_passengers.txt", "passengers.txt");
        cout << endl
             << "Passenger " << searchID << " updated successfully!" << endl;
    }
    else
    {
        remove("temp_passengers.txt");
        cout << endl
             << "Passenger " << searchID << " not found!" << endl;
    }

    cout << "Press Enter to continue...";
    cin.get();
}

void assignStaffToFlight()
{
    ClearScreen();
    cout << "=== ASSIGN STAFF TO FLIGHT ===" << endl
         << endl;

    string flightNo;
    cout << "Enter Flight Number: ";
    cin >> flightNo;

    // Verify flight exists
    ifstream flightsFile("flights.txt");
    bool flightExists = false;
    string line;

    // Skip header
    getline(flightsFile, line);

    while (getline(flightsFile, line))
    {
        stringstream ss(line);
        string currentFlight;
        getline(ss, currentFlight, '\t');
        if (currentFlight == flightNo)
        {
            flightExists = true;
            break;
        }
    }
    flightsFile.close();

    if (!flightExists)
    {
        cout << "Error: Flight " << flightNo << " does not exist!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Collect staff IDs
    vector<string> staffIDs;
    string staffID;
    cout << "\nEnter Staff IDs (one at a time, 0 to finish):" << endl;

    while (true)
    {
        cout << "Staff ID " << staffIDs.size() + 1 << ": ";
        cin >> staffID;

        if (staffID == "0")
        {
            break;
        }

        // Verify staff exists (optional)
        ifstream staffFile("Staff Details.txt");
        bool staffExists = false;

        // Skip header
        getline(staffFile, line);

        while (getline(staffFile, line))
        {
            stringstream ss(line);
            string currentID;
            getline(ss, currentID, '\t');
            if (currentID == staffID)
            {
                staffExists = true;
                break;
            }
        }
        staffFile.close();

        if (!staffExists)
        {
            cout << "Error: Staff " << staffID << " not found! Try again." << endl;
            continue;
        }

        staffIDs.push_back(staffID);

        if (staffIDs.size() >= 7)
        {
            cout << "Maximum 7 staff members reached." << endl;
            break;
        }
    }

    // Prepare record for Staff_Flight.txt
    ofstream outFile("Staff Flight.txt", ios::app);
    if (!outFile)
    {
        cout << "Error opening staff assignments file!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Write flight number
    outFile << flightNo;

    // Write staff IDs (up to 7)
    for (int i = 0; i < 7; i++)
    {
        outFile << "\t";
        if (i < staffIDs.size())
        {
            outFile << staffIDs[i];
        }
        else
        {
            outFile << "N/A"; // Or leave empty if preferred
        }
    }
    outFile << "\n";

    outFile.close();

    cout << "\nStaff assigned successfully to flight " << flightNo << "!" << endl;
    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}






void searchStaffByID()
{
    ClearScreen();
    cout << "=== SEARCH STAFF BY ID ===" << endl
         << endl;

    string searchID;
    cout << "Enter Staff ID to search: ";
    cin >> searchID;

    ifstream file("Staff Details.txt");
    if (!file.is_open())
    {
        cout << "Error opening staff records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    string line;
    bool found = false;

    // Skip header
    getline(file, line);

    while (getline(file, line))
    {
        stringstream ss(line);
        string staffID;
        getline(ss, staffID, '\t');

        if (staffID == searchID)
        {
            found = true;
            // Extract all details
            string name, role, email, salary, phone, address, username, password;

            getline(ss, name, '\t');
            getline(ss, role, '\t');
            getline(ss, email, '\t');
            getline(ss, salary, '\t');
            getline(ss, phone, '\t');
            getline(ss, address, '\t');
            getline(ss, username, '\t');
            getline(ss, password, '\t');

            // Display all details
            ClearScreen();
            cout << "=== STAFF DETAILS ===" << endl
                 << endl;
            cout << "Staff ID:" << staffID << endl;
            cout << "Name:" << name << endl;
            cout << "Role:" << role << endl;
            cout << "Email:" << email << endl;
            cout << "Salary:" << salary << endl;
            cout << "Phone:" << phone << endl;
            cout << "Address:" << address << endl;
            cout << "Username:" << username << endl;
            cout << "Password:" << string(password.length(), '*') << endl;

            break;
        }
    }

    file.close();

    if (!found)
    {
        cout << "Staff with ID " << searchID << " not found!" << endl;
    }

    cout << endl
         << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}






void displayPassengersByFlight()
{
    ClearScreen();
    cout << "=== PASSENGERS BY FLIGHT ===" << endl
         << endl;

    string flightID;
    cout << "Enter Flight ID: ";
    cin >> flightID;

    // First verify flight exists and get details
    ifstream flightsFile("flights.txt");
    bool flightExists = false;
    string line;
    string airline, from, to, depDate, depTime, arrDate, arrTime, duration, status;
    int totalSeats, availableSeats;

    // Skip header
    getline(flightsFile, line);

    while (getline(flightsFile, line))
    {
        stringstream ss(line);
        string currentFlight;
        getline(ss, currentFlight, '\t');

        if (currentFlight == flightID)
        {
            flightExists = true;
            getline(ss, airline, '\t');
            getline(ss, from, '\t');
            getline(ss, to, '\t');
            getline(ss, depDate, '\t');
            getline(ss, depTime, '\t');
            getline(ss, arrDate, '\t');
            getline(ss, arrTime, '\t');
            getline(ss, duration, '\t');
            ss >> totalSeats;
            ss.ignore();
            ss >> availableSeats;
            ss.ignore();
            getline(ss, status, '\t');
            break;
        }
    }
    flightsFile.close();

    if (!flightExists)
    {
        cout << "Flight " << flightID << " not found!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Display flight details
    ClearScreen();
    cout << "=== FLIGHT DETAILS ===" << endl
         << endl;
    cout << "Flight ID: " << flightID << endl;
    cout << "Airline: " << airline << endl;
    cout << "From: " << from << endl;
    cout << "To: " << to << endl;
    cout << "Departure: " << depDate << " at " << depTime << endl;
    cout << "Arrival: " << arrDate << " at " << arrTime << endl;
    cout << "Duration: " << duration << endl;
    cout << "Total Seats: " << totalSeats << endl;
    cout << "Available: " << availableSeats << endl;
    cout << "Status: " << status << endl;

    // Now search passengers
    ifstream passengersFile("passengers.txt");
    if (!passengersFile.is_open())
    {
        cout << "Error opening passenger records!" << endl;
        cout << "Press Enter to continue...";
        cin.ignore();
        cin.get();
        return;
    }

    // Display passenger header
    cout << "\nPassengers on Flight " << flightID << ":\n";
    cout << string(75, '-') << endl;
    cout << "ID\t\t"
         << "Name\t\t" << "Seat\t\t"
         << "Phone\t\t"
         << "Status\t\t" << endl;
    cout << string(75, '-') << endl;

    // Skip header
    getline(passengersFile, line);

    int passengerCount = 0;
    while (getline(passengersFile, line))
    {
        stringstream ss(line);
        string currentFlight;

        // Skip to FlightNo (9th field)
        for (int i = 0; i < 8; i++)
            getline(ss, currentFlight, '\t');
        getline(ss, currentFlight, '\t');

        if (currentFlight == flightID)
        {
            passengerCount++;
            ss.clear();
            ss.seekg(0);

            string id, name, seatNo, phone, status;

            // Extract fields in correct order
            getline(ss, id, '\t');     // 1. ID
            getline(ss, name, '\t');   // 2. Name
            getline(ss, line, '\t');   // 3. Skip Age
            getline(ss, line, '\t');   // 4. Skip Email
            getline(ss, phone, '\t');  // 5. Phone
            getline(ss, line, '\t');   // 6. Skip Address
            getline(ss, line, '\t');   // 7. Skip Departure
            getline(ss, line, '\t');   // 8. Skip Destination
            getline(ss, line, '\t');   // 9. Skip FlightNo
            getline(ss, seatNo, '\t'); // 10. SeatNo
            getline(ss, status, '\t'); // 11. Status

            // Display passenger info
            cout << id<<"\t\t"
                  << name<<"\t\t"
                 << seatNo<<"\t\t"
                  << phone<<"\t\t"
                  << status<<"\t\t" << endl;
        }
    }
    passengersFile.close();

    if (passengerCount == 0)
    {
        cout << "No passengers found for Flight " << flightID << endl;
    }
    else
    {
        cout << string(75, '-') << endl;
        cout << "Total passengers: " << passengerCount << endl;
    }

    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}

int main()
{
    while (true)
    {
        ClearScreen();
        welcome();

        cout << "1. Login as Admin" << endl;
        cout << "2. Login as Staff" << endl;
        cout << "3. Exit Program" << endl;

        int login;
        cout << "Enter your choice: ";
        cin >> login;

        if (login == 1)
        {
            bool found = adminLogin();
            if (found)
            {
                while (true)
                {
                    ClearScreen();
                    cout << "Login successful! Access granted." << endl;
                    cout << "1. Update your credentials" << endl;
                    cout << "2. Manage staff" << endl;
                    cout << "3. Manage Flights" << endl;
                    cout << "4. Passengers Info" << endl;
                    cout << "5. Booking Management" << endl;
                    cout << "6. Logout" << endl;

                    int choice;
                    cout << "Enter your choice: ";
                    cin >> choice;

                    if (choice == 1)
                    {
                        ClearScreen();
                        if (updateAdminCredentials())
                        {
                            cout << "Credentials updated successfully!" << endl;
                        }
                        else
                        {
                            cout << "Failed to update credentials." << endl;
                        }
                        cout << "Press Enter to continue...";
                        cin.ignore();
                        cin.get();
                    }
                    else if (choice == 2)
                    {
                        ClearScreen();
                        cout << "Manage staff" << endl;
                        // Staff management code
                        cout << "1. Add Staff" << endl;
                        cout << "2. Remove Staff" << endl;
                        cout << "3. View Staff List" << endl;
                        cout << "4. Update Staff Credentials" << endl;
                        cout << "5. Search staff by id" << endl;
                        cout << "6. Back to Admin Menu" << endl;
                        cout << "Enter your choice: ";
                        int staffChoice;
                        cin >> staffChoice;
                        if (staffChoice == 1)
                        {
                            ClearScreen();
                            cout << "Adding Staff..." << endl;
                            addStaff(); // Call the function to add staff
                        }
                        else if (staffChoice == 2)
                        {
                            ClearScreen();
                            cout << "Removing Staff..." << endl;
                            removeStaffByName(); // call function to remove staff
                        }
                        else if (staffChoice == 3)
                        {
                            ClearScreen();
                            cout << "Viewing Staff List..." << endl;
                            viewAllStaff(); // Code to view staff list
                        }
                        else if (staffChoice == 4)
                        {
                            ClearScreen();
                            cout << "Updating Staff Credentials..." << endl;
                            updateStaffDetails(); // Code to update staff credentials
                        }
                        else if (staffChoice == 5)
                        {
                            ClearScreen();
                            cout << "Searching Staff..." << endl;
                            searchStaffByID();
                        }
                        else if (staffChoice == 6)
                        {
                            continue; // Back to admin menu
                        }
                        else
                        {
                            cout << "Invalid choice!! ";
                            continue;
                        }
                    }
                    else if (choice == 3)
                    {
                        ClearScreen();
                        cout << "Manage Flights" << endl;
                        // Flight management code
                        cout << "1. Add Flight" << endl;
                        cout << "2. Remove Flight" << endl;
                        cout << "3. View Flight List" << endl;
                        cout << "4. Search a Flight" << endl;
                        cout << "5. Update a flight" << endl;
                        cout << "6. Assign Staff" << endl;
                        cout << "7. Back to admin menu" << endl;
                        cout << "Enter your choice: ";
                        int flightChoice;
                        cin >> flightChoice;
                        if (flightChoice == 1)
                        {
                            ClearScreen();
                            cout << "Adding Flight..." << endl;
                            // Call the function to add flight
                            addFlight();
                        }
                        else if (flightChoice == 2)
                        {
                            ClearScreen();
                            cout << "Removing Flight..." << endl;
                            // Call the function to remove flight
                            removeFlight();
                        }
                        else if (flightChoice == 3)
                        {
                            ClearScreen();
                            cout << "Viewing Flight List..." << endl;
                            // Code to view flight list
                            viewAllFlights();
                        }
                        else if (flightChoice == 4)
                        {
                            ClearScreen();
                            cout << "Searching a flight..." << endl;
                            // Code to search a flight
                            searchFlightByID();
                        }
                        else if (flightChoice == 5)
                        {
                            ClearScreen();
                            cout << "Updating a flight..." << endl;
                            // Code to update a flight
                            updateFlight();
                        }
                        else if (flightChoice == 6)
                        {
                            ClearScreen();
                            cout << "Assigning Staff..." << endl;
                            // function call to assign staff
                            assignStaffToFlight();
                        }
                        else if (flightChoice == 7)
                        {
                            continue; // Back to admin menu
                        }
                        else
                        {
                            cout << "Invalid choice!! ";
                            continue;
                        }
                    }
                    else if (choice == 4)
                    {
                        ClearScreen();
                        cout << "Passengers Info" << endl;
                        // Passenger info code

                        cout << "1. View all Passenger" << endl;
                        cout << "2. Search a Passenger" << endl;
                        cout << "3. Update a Passenger" << endl;
                        cout << "4. Back to Admin Menu" << endl;
                        cout << "Enter your choice: ";
                        int passengerChoice;
                        cin >> passengerChoice;
                        if (passengerChoice == 1)
                        {
                            ClearScreen();
                            cout << "Viewing all Passengers..." << endl;
                            // Code to view all passengers
                            viewAllPassengers();
                        }
                        else if (passengerChoice == 2)
                        {
                            ClearScreen();
                            cout << "Searching a Passenger..." << endl;
                            // Code to search a passenger
                            searchPassengerByName();
                        }
                        else if (passengerChoice == 3)
                        {
                            ClearScreen();
                            cout << "Updating a Passenger..." << endl;
                            // Code to update a passenger
                            updatePassengerDetails();
                        }
                        else if (passengerChoice == 4)
                        {
                            continue; // Back to admin menu
                        }
                        else
                        {
                            cout << "Invalid choice!! ";
                            continue;
                        }
                    }
                    else if (choice == 5)
                    {
                        ClearScreen();
                        cout << "Booking Management" << endl;
                        // Booking management code
                        cout << "1. Book a Ticket" << endl;
                        cout << "2. Cancel Ticket" << endl;
                        cout << "3. View All Bookings of a flight" << endl;
                        int bookingChoice;
                        cin >> bookingChoice;
                        if (bookingChoice == 1)
                        {
                            ClearScreen();
                            cout << "Adding Passenger..." << endl;
                            // Call the function to add passenger
                            addPassenger();
                        }
                        else if (bookingChoice == 2)
                        {
                            ClearScreen();
                            cout << "Removing Passenger..." << endl;
                            // Call the function to remove passenger
                            removePassengerByName();
                        }
                        else if (bookingChoice == 3)
                        {
                            ClearScreen();
                            cout << "View Flight and Passengers..." << endl;
                            // Call the function to remove passenger
                            displayPassengersByFlight();
                        }
                    }
                    else if (choice == 6)
                    {
                        break; // Logout and return to main menu
                    }
                    else
                    {
                        cout << "Invalid choice. Please try again." << endl;
                        cout << "Press Enter to continue...";
                        cin.ignore();
                        cin.get();
                    }
                }
            }
            else
            {
                cout << "Login failed! Invalid credentials." << endl;
                cout << "Press Enter to continue...";
                cin.ignore();
                cin.get();
            }
        }
        else if (login == 2)
        {
            bool success = staffLogin();
            if (success)
            {
                while (true)
                {
                    cout << "1. Book a Ticket" << endl;
                    cout << "2. Cancel Ticket" << endl;
                    cout << "3. View All Bookings of a flight" << endl;
                    cout << "4. View all Flights" << endl;
                    cout << "5. Exit" << endl;
                    cout << "Your choice: ";
                    int staffChoice;
                    cin >> staffChoice;
                    if (staffChoice == 1)
                    {
                        ClearScreen();
                        cout << "Adding Passenger..." << endl;
                        // Call the function to add passenger
                        addPassenger();
                    }
                    else if (staffChoice == 2)
                    {
                        ClearScreen();
                        cout << "Removing Passenger..." << endl;
                        // Call the function to remove passenger
                        removePassengerByName();
                    }
                    else if (staffChoice == 3)
                    {
                        ClearScreen();
                        cout << "View Flight and Passengers..." << endl;
                        // Call the function to remove passenger
                        displayPassengersByFlight();
                    }
                    else if (staffChoice == 4)
                    {
                        ClearScreen();
                        cout << "View all Flights..." << endl;
                        viewAllFlights();
                    }
                    else if (staffChoice == 5)
                    {
                        break;
                    }
                    else
                    {
                        cout << "Invalid choice. Please try again." << endl;
                        cout << "Press Enter to continue...";
                        cin.ignore();
                        cin.get();
                    }
                }
            }
            else
            {
                cout << "\nLogin failed! Invalid credentials." << endl;
            }
        }
        else if (login == 3)
        {
            ClearScreen();
            cout << "Exiting program..." << endl;
            break; // Exit the program
        }
        else
        {
            cout << "Invalid choice. Please try again." << endl;
            cout << "Press Enter to continue...";
            cin.ignore();
            cin.get();
        }
    }
    return 0;
}