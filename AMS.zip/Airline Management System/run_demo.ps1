# Airline Management System - Full Demo Script
# Run with: .\run_demo.ps1

Write-Host "`n"
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "   AIRLINE MANAGEMENT SYSTEM - FULL DEMO   " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "`n"
Start-Sleep -Seconds 3

# Function to simulate typing with delay
function Send-Input {
    param($text, $delay = 4)
    Write-Host $text -ForegroundColor Yellow
    Start-Sleep -Seconds $delay
}

# Create input sequence for full demo
$inputs = @"
1
admin
123
2
3

6
2
1
ST30
Michael Brown
Co-Pilot
michael@airways.com
55000
03331234567
E-11 Islamabad
mikeb
mike123

6
2
5
ST30

6
3
1
FL505
PakAir Express
ISB
LHE
2026-03-20
09:00 AM
2026-03-20
11:00 AM
2h
120

3

4
FL505

7
4
1

2
Michael Brown

4
5
1
FL505
A1
ISB
LHE
P100
Ahmed Hassan
28
ahmed@mail.com
03009998877
G-9 Islamabad

3
FL505

6
6
2
o
1
4

1
FL505
A2
ISB
LHE
P101
Ayesha Khan
25
ayesha@mail.com
03451112233
F-6 Islamabad

3
FL505

5
3
"@

# Save inputs to temp file
$inputs | Out-File -FilePath "temp_demo_input.txt" -Encoding ASCII

Write-Host "Starting Airline Management System..." -ForegroundColor Green
Write-Host "Recording in progress - Watch the terminal!`n" -ForegroundColor Magenta
Start-Sleep -Seconds 3

# Run with inputs
Get-Content "temp_demo_input.txt" | ForEach-Object {
    $_
    Start-Sleep -Milliseconds 800
} | & ".\AMS.exe"

# Cleanup
Remove-Item "temp_demo_input.txt" -ErrorAction SilentlyContinue

Write-Host "`n"
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "         DEMO COMPLETED SUCCESSFULLY       " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
