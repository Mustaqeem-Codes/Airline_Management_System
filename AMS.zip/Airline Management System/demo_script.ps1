$process = Start-Process -FilePath ".\AMS.exe" -NoNewWindow -PassThru -RedirectStandardInput ".\demo_pipe.txt"

# Create named pipe for input
$pipe = [System.IO.File]::CreateText(".\demo_pipe.txt")

function Send-Input($text, $delay = 2) {
    Start-Sleep -Seconds $delay
    $pipe.WriteLine($text)
    $pipe.Flush()
}

# DEMO SEQUENCE
Send-Input "1" 3        # Select Admin Login
Send-Input "admin" 2    # Username
Send-Input "123" 2      # Password

# Inside Admin Menu
Send-Input "2" 3        # Manage Staff
Send-Input "3" 2        # View Staff List
Send-Input "" 3         # Press Enter to continue
Send-Input "6" 2        # Back to Admin Menu

Send-Input "2" 2        # Manage Staff again
Send-Input "1" 2        # Add Staff

# Add new staff details
Send-Input "ST30" 2
Send-Input "Emily Davis" 2
Send-Input "Flight Attendant" 2
Send-Input "emily@airline.com" 2
Send-Input "48000" 2
Send-Input "03331234567" 2
Send-Input "DHA Phase 5 Lahore" 2
Send-Input "emilyd" 2
Send-Input "emily123" 2
Send-Input "" 2         # Press Enter

Send-Input "6" 2        # Back to Admin Menu
Send-Input "6" 2        # Logout
Send-Input "3" 2        # Exit

$pipe.Close()
Wait-Process -InputObject $process
