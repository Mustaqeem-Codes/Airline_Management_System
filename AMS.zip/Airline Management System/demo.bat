@echo off
chcp 65001 >nul
echo.
echo ============================================================
echo    AIRLINE MANAGEMENT SYSTEM - FULL FEATURE DEMONSTRATION
echo ============================================================
echo.
timeout /t 3 /nobreak >nul

echo Starting Airline Management System...
timeout /t 2 /nobreak >nul

(
echo 1
timeout /t 2 /nobreak >nul
echo admin
timeout /t 2 /nobreak >nul
echo 123
timeout /t 2 /nobreak >nul
echo 2
timeout /t 2 /nobreak >nul
echo 3
timeout /t 3 /nobreak >nul
echo.
timeout /t 2 /nobreak >nul
echo 6
timeout /t 2 /nobreak >nul
echo 6
timeout /t 2 /nobreak >nul
echo 3
) | AMS.exe

pause
